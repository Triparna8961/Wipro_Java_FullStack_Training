package com.example.library.enums;

public enum RoleName {
STUDENT, FACULTY, STAFF, EXTERNAL
}