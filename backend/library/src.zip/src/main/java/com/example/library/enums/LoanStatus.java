package com.example.library.enums;


public enum LoanStatus {
BORROWED, RETURNED, LATE
}